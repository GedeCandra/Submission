SELECT PrdctName, CompanyName, ContactName
FROM (SELECT PrdctName, min (OrderDate), CompanyName, ContactName
FROM (SELECT ProductName AS PrdctName ,Id AS PrdctId FROM 'Product' WHERE Discontinued != 0) as DiscontinuedPrdct
INNER JOIN OrderDetail on ProductId = PrdctId
INNER JOIN 'Order' on 'Order'.Id = OrderDetail.OrderId
INNER JOIN Customer on CustomerId = Customer.Id
GROUP BY PrdctId)
ORDER BY PrdctName ASC;