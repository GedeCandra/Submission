SELECT CategoryName, COUNT (*) AS CategoryCount, ROUND (AVG (UnitPrice), 2) AS UnitPriceAVG, MIN (UnitPrice) AS UnitPriceMIN, MAX (UnitPrice) AS UnitPriceMAX, SUM (UnitsOnOrder) AS TUOnOrder
FROM 'Product' INNER JOIN 'Category' on CategoryId = Category.Id
GROUP BY CategoryId
HAVING CategoryCount > 10
ORDER BY CategoryId;