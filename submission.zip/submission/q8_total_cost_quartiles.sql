WITH Expenditures AS (SELECT IFNULL (Cstmr.CompanyName, 'MISSING_NAME') AS CompanyName, Ordr.CustomerId, ROUND (SUM(OrdrDetail.Quantity * OrdrDetail.UnitPrice), 2) AS TotalExpenditure
FROM 'Order' AS Ordr
INNER JOIN OrderDetail OrdrDetail on OrdrDetail.OrderId = Ordr.Id
LEFT JOIN Customer Cstmr on Cstmr.Id = Ordr.CustomerId
GROUP BY Ordr.CustomerId),

Quartiles AS (SELECT *, NTILE (4) OVER (ORDER BY TotalExpenditure ASC) AS Total
FROM Expenditures)

SELECT CompanyName, CustomerId, TotalExpenditure
FROM Quartiles
WHERE Total = 1
ORDER BY TotalExpenditure ASC;